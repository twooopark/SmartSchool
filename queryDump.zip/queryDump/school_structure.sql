CREATE DATABASE  IF NOT EXISTS `smartschool` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `smartschool`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: smartschool
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classroom`
--

DROP TABLE IF EXISTS `classroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classroom` (
  `﻿No` int(11) NOT NULL AUTO_INCREMENT,
  `Location` varchar(20) DEFAULT NULL,
  `Serial` varchar(20) DEFAULT NULL,
  `MAC(DEC)` bigint(18) NOT NULL,
  `MAC(HEX)` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`﻿No`,`MAC(DEC)`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classroom`
--

LOCK TABLES `classroom` WRITE;
/*!40000 ALTER TABLE `classroom` DISABLE KEYS */;
INSERT INTO `classroom` VALUES (1,'과학실','TM-WP-000031',53876146660824,'D8-65-95-04-00-31'),(2,'4학년1반','TM-WP-000032',54975658288600,'D8-65-95-04-00-32'),(3,'꿈나무교실1','TM-WP-000033',56075169916376,'D8-65-95-04-00-33'),(4,'1학년2반','TM-WP-000034',57174681544152,'D8-65-95-04-00-34'),(5,'지하세미나실','TM-WP-000035',58274193171928,'D8-65-95-04-00-35'),(6,'영어교실','TM-WP-000036',59373704799704,'D8-65-95-04-00-36'),(7,'6학년1반','TM-WP-000037',60473216427480,'D8-65-95-04-00-37'),(8,'음악실','TM-WP-000038',61572728055256,'D8-65-95-04-00-38'),(9,'도서관','TM-WP-000039',62672239683032,'D8-65-95-04-00-39'),(10,'3학년2반','TM-WP-00003a',63771751310808,'D8-65-95-04-00-3a'),(11,'열린 교육실','TM-WP-00003b',64871262938584,'D8-65-95-04-00-3b'),(12,'2학년1반','TM-WP-00003c',65970774566360,'D8-65-95-04-00-3c'),(13,'5학년1반','TM-WP-00003d',67070286194136,'D8-65-95-04-00-3d'),(14,'미래교실','TM-WP-00003e',68169797821912,'D8-65-95-04-00-3e'),(15,'1학년1반','TM-WP-00003f',69269309449688,'D8-65-95-04-00-3f'),(16,'3학년1반','TM-WP-000040',70368821077464,'D8-65-95-04-00-40'),(17,'5학년2반','TM-WP-000041',71468332705240,'D8-65-95-04-00-41'),(18,'꿈나무교실2','TM-WP-000042',72567844333016,'D8-65-95-04-00-42'),(19,'4학년2반','TM-WP-000043',73667355960792,'D8-65-95-04-00-43'),(20,'2학년2반','TM-WP-000044',74766867588568,'D8-65-95-04-00-44'),(21,'6학년2반','TM-WP-000045',75866379216344,'D8-65-95-04-00-45');
/*!40000 ALTER TABLE `classroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_data`
--

DROP TABLE IF EXISTS `sensor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data` (
  `MAC` bigint(18) DEFAULT NULL,
  `TYPE` int(11) DEFAULT NULL,
  `DATA` int(11) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_data`
--

LOCK TABLES `sensor_data` WRITE;
/*!40000 ALTER TABLE `sensor_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_data_update`
--

DROP TABLE IF EXISTS `sensor_data_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data_update` (
  `MAC` bigint(18) NOT NULL,
  `TYPE` int(11) NOT NULL,
  `DATA` int(11) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`MAC`,`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_data_update`
--

LOCK TABLES `sensor_data_update` WRITE;
/*!40000 ALTER TABLE `sensor_data_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_data_update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-18 17:47:10
