ALTER TABLE `smartschool`.`classroom` 
ADD COLUMN `Data_coords` POINT NULL AFTER `MAC_HEX`;



UPDATE `smartschool`.`classroom`
SET
 `Data_coords` = GeomFromText('POINT(37.489890 127.013058)')
WHERE `No` = 1;



SELECT astext(`Data_coords`) FROM smartschool.classroom

출처: http://liyoucat.tistory.com/14 [괭발 잘 하고픈 괭발자 리유]