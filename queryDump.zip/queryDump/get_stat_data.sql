SELECT 
    LOCATION AS CLASSROOM_NAME,
    MAC_HEX AS MAC,
    INFO AS TYPE,
    DATA,
    DATE_FORMAT(TIME, "%Y-%m-%d %H:%i:%s") AS TIME
FROM
    classroom
        LEFT OUTER JOIN
    sensor_data_update ON sensor_data_update.MAC = classroom.MAC_DEC
        LEFT OUTER JOIN
    sensor ON sensor.TYPE = sensor_data_update.TYPE
ORDER BY CLASSROOM_NAME , TYPE