SELECT * 
FROM smartschool.ble_io_test, student
where CLASSROOM_MAC = 241961354487256 and ble_io_test.BLE_MAC = student.BLE_MAC 

and student.BLE_MAC = 276995593176332


delete
SELECT * 
FROM smartschool.ble_io_update 
where IN_TIME > '2017-11-23'


INSERT INTO `smartschool`.`ble_io_test`(`BLE_MAC`,`IN_TIME`,`OUT_TIME`) 
    (SELECT r.BLE_MAC as BLE_MAC, MIN(r.TIME) as IN_TIME, MAX(r.TIME) as OUT_TIME 
    FROM RAW_BLE as r, student as s 
    where r.CLASSROOM_MAC = s.CLASSROOM_MAC and between time < '2017-11-23' and time > '2017-11-22'
    GROUP BY r.BLE_MAC)
ON DUPLICATE KEY UPDATE OUT_TIME=VALUES(OUT_TIME); 


INSERT INTO `smartschool`.`ble_io_update`
(`BLE_MAC`,
`IN_TIME`,
`OUT_TIME`)
VALUES
(276995593176332,
'2017-11-22 09:56:16',
'2017-11-22 11:00:02');











SELECT distinct(MAC) FROM smartschool.sensor_data_update
where TIME < '2017-11-24 17:00:00'


SELECT distinct(MAC), c.LOCATION, t.NAME 
FROM smartschool.sensor_data_update as s, classroom as c left outer join teacher as t on c.MAC_DEC=t.CLASSROOM_MAC 
where s.MAC=c.MAC_DEC and  s.TIME < '2017-11-24 17:00:00' 


select K.m, K.Location, t.name
from
(
SELECT distinct(s.MAC) as m, c.LOCATION
FROM smartschool.sensor_data_update as s, classroom as c 
where s.MAC=c.MAC_DEC and  s.TIME < '2017-11-24 17:00:00' 
)as K left outer join teacher as t on K.m=t.CLASSROOM_MAC 








select cm,sm
    from
      (
      select sm, cm, cnt,
            @s_rank := IF(@current_s = sm, @s_rank + 1, 1) AS s_rank,
            @current_s := sm
      from
        (
        select s.BLE_MAC as sm, c.MAC_DEC as cm, count(*) as cnt
        from RAW_BLE as s, classroom as c
        where s.CLASSROOM_MAC = c.MAC_DEC and( c.LOCATION like '%반' or c.LOCATION = 'TEST_BLE')
        group by s.BLE_MAC, c.MAC_DEC
        having cnt > 10
        order by BLE_MAC, cnt desc
         )as t
      )as k
    where s_rank = 1
    
    
    
  
    
    
  SELECT s.idx as no, s.name as student_name, "등교" as student_state 
  FROM classroom as c, student as s 
  WHERE c.MAC_DEC = s.CLASSROOM_MAC and c.LOCATION = "1학년2반"
  group by s.idx
  

  
SELECT student.CLASSROOM_MAC, count(*) as cnt 
    FROM student 
    where CLASSROOM_MAC = 57174681544152
    GROUP BY student.CLASSROOM_MAC
    
      SELECT s.idx as no, s.name as student_name, "등교" as student_state 
  FROM classroom as c, student as s, ble_io_update as b 
  WHERE c.MAC_DEC = s.CLASSROOM_MAC and b.BLE_MAC = s.BLE_MAC
  
  
  
  
  
  
  
  
SELECT z.no as no, z.LOCATION as class_name, t.NAME as teacher_name, sc.cnt as student_cnt, m.SERIAL as device_id 
FROM zone as z 
left outer join teacher as t on z.MAC = t.CLASSROOM_MAC
left outer join module as m on m.MAC = z.MAC
left outer join (SELECT st.CLASSROOM_MAC, count(*) as cnt 
FROM student as st
GROUP BY st.CLASSROOM_MAC) as sc on z.MAC = sc.CLASSROOM_MAC 
ORDER BY z.LOCATION 

