SELECT s.INFO AS type, DATA, count(*) as cnt 
FROM (select MAC, TYPE, TIME, DATA from sensor_error) as err, classroom as c, sensor as s 
WHERE s.type = err.type and err.MAC = c.MAC_DEC 
group by type, DATA


SELECT c.LOCATION as loc, s.INFO AS type, DATA, count(*) as cnt 
FROM (select MAC, TYPE, TIME, DATA from sensor_error) as err, classroom as c, sensor as s 
WHERE s.type = err.type and err.MAC = c.MAC_DEC 
group by loc, type, DATA


SELECT c.LOCATION as loc, s.INFO AS type, DATE_FORMAT(err.TIME, "%Y-%m-%d") AS time, DATA, count(*) as cnt 
FROM (select MAC, TYPE, TIME, DATA from sensor_error) as err, classroom as c, sensor as s 
WHERE s.type = err.type and err.MAC = c.MAC_DEC 
group by loc, type, DATE_FORMAT(err.TIME, "%Y-%m-%d"), DATA