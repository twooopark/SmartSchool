INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363907,
256,
63,
'2017-10-15 21:56:05');
INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363905,
512,
15,
'2017-10-15 21:56:01');INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363904,
1024,
284,
'2017-10-15 21:56:01');INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363903,
2048,
474,
'2017-10-15 21:56:01');INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363902,
4096,
543,
'2017-10-15 21:56:01');INSERT INTO `smartschool`.`sensor_data_update`
(`MAC`,
`TYPE`,
`DATA`,
`TIME`)
VALUES
(237930803363901,
256,
62,
'2017-10-15 21:56:01');