INSERT INTO `smartschool`.`student`
(`CLASSROOM_MAC`,
`BLE_MAC`)
(
	select cm,sm
	from
		(
		select sm, cm, cnt,
				  @s_rank := IF(@current_s = sm, @s_rank + 1, 1) AS s_rank,
				  @current_s := sm
		from
			(
			select s.BLE_MAC as sm, c.MAC_DEC as cm, count(*) as cnt
			from RAW_BLE as s, classroom as c
			where s.CLASSROOM_MAC = c.MAC_DEC and( c.LOCATION like '%반' or c.LOCATION = 'TEST_BLE')
			group by s.BLE_MAC, c.MAC_DEC
			having cnt > 10
			order by BLE_MAC, cnt desc
		   )as t
		)as k
	where s_rank = 1
)
ON DUPLICATE KEY UPDATE CLASSROOM_MAC=VALUES(CLASSROOM_MAC), BLE_MAC=VALUES(BLE_MAC); 