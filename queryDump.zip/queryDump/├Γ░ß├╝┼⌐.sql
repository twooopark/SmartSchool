

INSERT INTO `smartschool`.`ble_io_update`
(`BLE_MAC`,`IN_TIME`,`OUT_TIME`)
(
SELECT r.BLE_MAC as BLE_MAC, MIN(r.TIME) as IN_TIME, MAX(r.TIME) as OUT_TIME
FROM RAW_BLE as r, student as s
where r.CLASSROOM_MAC = s.CLASSROOM_MAC
GROUP BY r.BLE_MAC
)
ON DUPLICATE KEY UPDATE IN_TIME=VALUES(IN_TIME), OUT_TIME=VALUES(OUT_TIME); 

//delete from ble_io_update

SELECT DATE_FORMAT(b.time, "%Y-%m-%d %H"),b.BLE_MAC, s.NAME, c.LOCATION
FROM RAW_BLE as b, student as s, classroom as c
where time between '2017-11-21 06' and '2017-11-21 18'
and s.BLE_MAC = b.BLE_MAC and s.CLASSROOM_MAC = c.MAC_DEC
group by DATE_FORMAT(b.time, "%Y-%m-%d %H"), b.BLE_MAC, s.NAME, c.LOCATION

276995593176332	241961354487256	2017-11-22 15:14:33	2017-11-22 15:29:57

SELECT b.BLE_MAC, s.NAME, c.LOCATION, b.m
FROM student as s, classroom as c,
(
SELECT r.BLE_MAC, MIN(r.TIME) as i, MAX(r.TIME) as o
FROM RAW_BLE as r, student as s
where r.CLASSROOM_MAC = s.CLASSROOM_MAC and time between '2017-11-22 00:00:00' and '2017-11-22 23:59:59'
GROUP BY r.BLE_MAC
) as b
where s.BLE_MAC = b.BLE_MAC and s.CLASSROOM_MAC = c.MAC_DEC
group by b.BLE_MAC, s.NAME, c.LOCATION, b.m




SELECT b.B_M, s.NAME, c.LOCATION
FROM student as s, classroom as c,
(
SELECT r.BLE_MAC as B_M, r.CLASSROOM_MAC as C_M, MIN(r.TIME) as mn, MAX(r.TIME) as mx
FROM RAW_BLE as r
where time between '2017-11-21 06' and '2017-11-21 18'
GROUP BY r.BLE_MAC, r.CLASSROOM_MAC
) as b
where s.BLE_MAC = b.B_M and s.CLASSROOM_MAC = c.MAC_DEC
group by b.B_M, s.NAME, c.LOCATION