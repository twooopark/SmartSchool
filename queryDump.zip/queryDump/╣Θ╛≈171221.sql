CREATE DATABASE  IF NOT EXISTS `smartschool` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `smartschool`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: smartschool
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `RAW_BLE`
--

DROP TABLE IF EXISTS `RAW_BLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RAW_BLE` (
  `CLASSROOM_MAC` bigint(18) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL,
  `BLE_MAC` bigint(18) DEFAULT NULL,
  `BLE_TIME` datetime DEFAULT NULL,
  `RSSI` int(11) DEFAULT NULL,
  `DATA` varchar(10000) DEFAULT NULL,
  KEY `timeidx` (`TIME`),
  KEY `ble_index` (`BLE_TIME`,`BLE_MAC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TODAY_BLE`
--

DROP TABLE IF EXISTS `TODAY_BLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TODAY_BLE` (
  `BLE_MAC` bigint(18) DEFAULT NULL,
  `NOW` datetime DEFAULT NULL,
  `LAST_LOC` bigint(18) DEFAULT NULL,
  `RSSI` int(11) DEFAULT NULL,
  `DATA` varchar(45) DEFAULT NULL,
  KEY `today_ble_index` (`NOW`,`BLE_MAC`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attend_check`
--

DROP TABLE IF EXISTS `attend_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attend_check` (
  `BLE_MAC` bigint(11) unsigned NOT NULL,
  `IN_TIME` datetime NOT NULL,
  `OUT_TIME` datetime DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  PRIMARY KEY (`BLE_MAC`,`IN_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attend_check2`
--

DROP TABLE IF EXISTS `attend_check2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attend_check2` (
  `BLE_MAC` bigint(20) NOT NULL,
  `IN_TIME` datetime NOT NULL,
  `OUT_TIME` datetime DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  PRIMARY KEY (`BLE_MAC`,`IN_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ble_io_test`
--

DROP TABLE IF EXISTS `ble_io_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ble_io_test` (
  `BLE_MAC` bigint(11) unsigned NOT NULL,
  `IN_TIME` datetime NOT NULL,
  `OUT_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`BLE_MAC`,`IN_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ble_io_update`
--

DROP TABLE IF EXISTS `ble_io_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ble_io_update` (
  `BLE_MAC` bigint(11) unsigned NOT NULL,
  `IN_TIME` datetime NOT NULL,
  `OUT_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`BLE_MAC`,`IN_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classroom`
--

DROP TABLE IF EXISTS `classroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classroom` (
  `NO` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION` varchar(20) DEFAULT NULL,
  `SERIAL` varchar(20) NOT NULL,
  `MAC_DEC` bigint(11) unsigned NOT NULL,
  `MAC_HEX` varchar(20) NOT NULL,
  `COORD_X` int(4) DEFAULT '100',
  `COORD_Y` int(4) DEFAULT '100',
  `REPLACED_DATE` datetime DEFAULT '2017-11-01 00:00:00',
  `DESCRIPTION` varchar(45) DEFAULT '내용 없음',
  PRIMARY KEY (`MAC_DEC`),
  UNIQUE KEY `NO_UNIQUE` (`NO`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='class_info & device_info (구버전) // zone과 module로 정규화함';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `classroom_new`
--

DROP TABLE IF EXISTS `classroom_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classroom_new` (
  `NO` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION` varchar(20) NOT NULL,
  `MAC` bigint(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`LOCATION`),
  UNIQUE KEY `NO_UNIQUE` (`NO`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COMMENT='교실관리 & 디바이스 관리용;... DB 스키마 다시 설계해야겠다';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module` (
  `NO` int(11) NOT NULL AUTO_INCREMENT,
  `SERIAL` varchar(20) NOT NULL,
  `MAC` bigint(11) unsigned NOT NULL,
  `REPLACED_DATE` datetime DEFAULT '2017-11-01 00:00:00',
  `DESCRIPTION` varchar(45) DEFAULT '내용 없음',
  PRIMARY KEY (`MAC`),
  UNIQUE KEY `NO_UNIQUE` (`NO`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='디바이스 정보';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor`
--

DROP TABLE IF EXISTS `sensor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor` (
  `TYPE` int(1) DEFAULT NULL,
  `NAME` varchar(20) DEFAULT NULL,
  `INFO` varchar(20) DEFAULT NULL,
  `MIN` int(4) DEFAULT NULL,
  `MAX` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_data`
--

DROP TABLE IF EXISTS `sensor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `MAC` bigint(11) unsigned DEFAULT NULL,
  `TYPE` int(1) DEFAULT NULL,
  `DATA` int(4) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `timeidx` (`TIME`)
) ENGINE=InnoDB AUTO_INCREMENT=89335911 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_data_daily`
--

DROP TABLE IF EXISTS `sensor_data_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data_daily` (
  `loc` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` datetime NOT NULL,
  `avge` int(4) DEFAULT NULL,
  PRIMARY KEY (`loc`,`type`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_data_hourly`
--

DROP TABLE IF EXISTS `sensor_data_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data_hourly` (
  `loc` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` datetime NOT NULL,
  `avge` int(4) DEFAULT NULL,
  PRIMARY KEY (`loc`,`type`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_data_update`
--

DROP TABLE IF EXISTS `sensor_data_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_data_update` (
  `MAC` bigint(18) NOT NULL,
  `TYPE` int(11) NOT NULL,
  `DATA` int(11) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`MAC`,`TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_error`
--

DROP TABLE IF EXISTS `sensor_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_error` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `MAC` bigint(11) unsigned DEFAULT NULL,
  `TYPE` int(1) unsigned DEFAULT NULL,
  `DATA` int(4) DEFAULT NULL,
  `TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `timeidx` (`TIME`)
) ENGINE=InnoDB AUTO_INCREMENT=6056673 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_error_daily`
--

DROP TABLE IF EXISTS `sensor_error_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_error_daily` (
  `loc` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` datetime NOT NULL,
  `cnt` int(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`loc`,`type`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sensor_error_hourly`
--

DROP TABLE IF EXISTS `sensor_error_hourly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sensor_error_hourly` (
  `loc` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` datetime NOT NULL,
  `cnt` int(4) unsigned DEFAULT NULL,
  PRIMARY KEY (`loc`,`type`,`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `CLASSROOM_MAC` bigint(11) unsigned NOT NULL,
  `BLE_MAC` bigint(11) unsigned NOT NULL,
  `NAME` varchar(20) NOT NULL DEFAULT '박두리',
  `BIRTH` datetime NOT NULL DEFAULT '1992-12-04 00:00:00',
  `PHONE_NUM` varchar(15) NOT NULL DEFAULT '010-9999-9999',
  `EMAIL` varchar(30) DEFAULT 'twooo.park@gmail.com',
  `ADDRESS` varchar(45) DEFAULT '서울특별시 구로구 디지털로 26길 72, 서울시창업지원센터 214호',
  `PARENT_NAME` varchar(20) DEFAULT '박부모',
  `PARENT_PHONE` varchar(15) DEFAULT '019-9999-9999',
  `STATE` varchar(10) DEFAULT '재학',
  `ETC` varchar(45) DEFAULT '부모님 맞벌이',
  PRIMARY KEY (`BLE_MAC`),
  UNIQUE KEY `idx_UNIQUE` (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8 COMMENT='(임시데이터)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher` (
  `idx` int(11) NOT NULL AUTO_INCREMENT,
  `CLASSROOM_MAC` bigint(11) unsigned NOT NULL,
  `NAME` varchar(20) DEFAULT '박두리',
  `PERIOD_ST` datetime DEFAULT '2017-09-01 10:00:00',
  `PERIOD_END` datetime DEFAULT '2017-12-21 19:00:00',
  UNIQUE KEY `idx_UNIQUE` (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `zone_temp`
--

DROP TABLE IF EXISTS `zone_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zone_temp` (
  `NO` int(11) NOT NULL AUTO_INCREMENT,
  `LOCATION` varchar(20) NOT NULL,
  `MAC` bigint(11) unsigned NOT NULL DEFAULT '0',
  `COORD_X` int(4) DEFAULT '100',
  `COORD_Y` int(4) DEFAULT '100',
  PRIMARY KEY (`LOCATION`),
  UNIQUE KEY `NO_UNIQUE` (`NO`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='없앨예정.,.,,,,,,.,';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-21 16:07:49
